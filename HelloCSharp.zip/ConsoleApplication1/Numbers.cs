﻿/* 
 * Problem 6. Print Numbers• 
 * Write a program to print the numbers  1, 101 and 1001 , each at a separate line.
*/

using System;

class Numbers
{
    static void Main()
    {
        int firstNumber = 1;
        int secondNumber = 101;
        int thirdNumber = 1001;

        Console.WriteLine(firstNumber);
        Console.WriteLine(secondNumber);
        Console.WriteLine(thirdNumber);

    }
}

