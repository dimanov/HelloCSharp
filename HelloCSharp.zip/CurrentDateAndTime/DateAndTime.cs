﻿// This is a console application that prints the current date and time.

using System;

class DateAndTime
{
    static void Main()
    {
        DateTime now = DateTime.Now;
        Console.WriteLine("The current date and time is: " + now);
    }
}

