﻿// Problem 4. This program prints "Hello, C#!"

using System;

class HelloCSharp
{
    static void Main()
    {
        Console.WriteLine("Hello, C#!");
    }
}
