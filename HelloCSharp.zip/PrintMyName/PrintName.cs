﻿// Problem 5. Print Your Name
// This is a console application that prints my names on one line

using System;

class PrintName
{
    static void Main()
    {
        string myFirstName = "Nikolay";
        string myLastName = "Dimanov";
        Console.WriteLine(myFirstName + " " + myLastName);
    }
}
