﻿/*
Problem 7. Print First and Last Name
This is a console application that prints my first and last name, each at a separate line.
*/
using System;

class PrintNames
{
    static void Main()
    {
        string myFirstName = "Nikolay";
        string myLastName = "Dimanov";
        Console.WriteLine(myFirstName);
        Console.WriteLine(myLastName);

    }
}

