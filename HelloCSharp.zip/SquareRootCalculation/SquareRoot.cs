﻿/*
 Problem 8. Square Root
 */

using System;

class SquareRoot
{
    static void Main()
    {
        double firstNumber = 12345;

        Console.WriteLine(Math.Sqrt(firstNumber));
    }
}
